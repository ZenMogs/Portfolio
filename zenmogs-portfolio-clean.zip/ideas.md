# ZenMogs Design Direction

## Three Direction Options

### Theme Name: Signal Lab
Very dark, precise, experimental interface language with a single high-voltage accent that makes the work feel like an active build system.
Probability: 0.07

### Theme Name: Soft Hardware
Warm graphite, brushed-metal neutrals, and restrained amber details that frame ZenMogs as a thoughtful product maker.
Probability: 0.03

### Theme Name: Field Notes
Editorial portfolio with paper-like contrast, technical annotations, and a maker-journal feeling rather than a dashboard aesthetic.
Probability: 0.05

## Chosen Direction: Signal Lab

### Design Movement
Contemporary digital brutalism with product-launch restraint, inspired by instrument panels, developer tooling, and experimental interface systems.

### Core Principles
1. Every section should feel like a distinct instrument in one coherent build environment.
2. Motion should communicate state, depth, and responsiveness instead of decoration.
3. Strong typography and asymmetrical composition should create hierarchy before ornament.
4. The lime signal color is scarce and meaningful: it marks progress, active states, and important actions.

### Color Philosophy
The background is near-black graphite to create a quiet, premium field. White and cool gray carry the information hierarchy. Electric lime is the signature signal: it indicates something live, selected, or currently being built. Small amounts of cobalt and amber separate technical domains without turning the interface into neon cyberpunk.

### Layout Paradigm
Use a long-form scroll as a narrative build log. Sections alternate between asymmetric split layouts, offset bento panels, and wide instrument-like compositions. Avoid a centered marketing column; let the visual system drift across the page while keeping content anchored to a consistent left rail.

### Signature Elements
- Thin blueprint grid and scanline textures behind content.
- Lime “signal” dots, bars, and active underlines for state changes.
- Instrument-panel cards with clipped corners, hairline borders, and subtle depth.

### Interaction Philosophy
Interactions should feel like the interface notices the visitor. Hover states reveal additional context, cards tilt slightly, buttons pull toward the cursor, and navigation updates based on the current section. Every interaction remains legible and usable with keyboard and reduced-motion preferences.

### Animation
Use quick, physical transitions for buttons and nav. Use slow ambient drift for background particles and grid movement. Reveal content with small vertical translations and opacity, staggered lightly. Dialogs should scale from 0.96 with a soft fade. Never animate layout dimensions; prefer transform and opacity. Disable nonessential motion under prefers-reduced-motion.

### Typography System
Display: Space Grotesk, 700/600, used for hero headlines and section titles.
Body: DM Sans, 400/500, used for paragraphs, labels, and metadata.
Technical: JetBrains Mono, 400/500, used for terminal UI, timestamps, tags, and system labels.
Hierarchy: oversized compact hero display, uppercase tracking labels, readable 16–18px body copy, and small mono metadata for machine-like contrast.

### Brand Essence
ZenMogs is a student developer who turns wide-ranging technical curiosity into real digital builds for people who value experimentation and useful craft.
Personality: curious, relentless, precise.

### Brand Voice
Headlines are direct, energetic, and slightly conversational. CTAs sound like an invitation to inspect the work, not a sales pitch. Microcopy is brief and honest about what is in development or placeholder.
Example lines: “Build wide. Ship thoughtfully.” / “Open the workbench.”

### Wordmark & Logo
The wordmark uses a custom spaced uppercase treatment with a lime terminal cursor accent. The mark is an angular interlocking bracket/spark symbol that suggests multiple systems locking together and moving forward.

### Signature Brand Color
Signal Lime — #C8FF3D. It is bright enough to own the interface but is used sparingly so active states feel earned.
