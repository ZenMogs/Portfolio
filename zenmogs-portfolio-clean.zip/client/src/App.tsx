/* Cinematic ZenMogs system: route changes are treated as portal jumps between distinct instruments, not ordinary page swaps. */
import { AnimatePresence, motion } from "framer-motion";
import { Route, Switch, useLocation } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import {
  AboutPage,
  ContactPage,
  ExperiencePage,
  HomePage,
  MissionsPage,
  ProjectsPage,
  SkillsPage,
  SiteLayout,
} from "./pages/Home";

function Router() {
  const [location] = useLocation();
  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={location}
        className="route-stage"
        initial={{ opacity: 0, scale: 0.985, filter: "blur(10px)" }}
        animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
        exit={{ opacity: 0, scale: 1.015, filter: "blur(12px)" }}
        transition={{ duration: 0.34, ease: [0.23, 1, 0.32, 1] }}
      >
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/about" component={AboutPage} />
          <Route path="/skills" component={SkillsPage} />
          <Route path="/projects" component={ProjectsPage} />
          <Route path="/experience" component={ExperiencePage} />
          <Route path="/missions" component={MissionsPage} />
          <Route path="/contact" component={ContactPage} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster theme="dark" position="bottom-right" />
          <SiteLayout>
            <Router />
          </SiteLayout>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
