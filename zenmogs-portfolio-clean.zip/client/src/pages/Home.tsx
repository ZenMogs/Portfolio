/* Cinematic ZenMogs system: every route is a distinct instrument in one digital world; scroll, hover, and route changes should feel physical, purposeful, and fast. */
import { AnimatePresence, motion, useScroll, useTransform } from "framer-motion";
import { Link, useLocation } from "wouter";
import { useEffect, useRef, useState, type PointerEvent, type ReactNode } from "react";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bot,
  Braces,
  Check,
  ChevronRight,
  CircleDot,
  Code2,
  Cog,
  ExternalLink,
  Gamepad2,
  Github,
  Globe2,
  Instagram,
  Layers3,
  Mail,
  MessageSquare,
  MoveUpRight,
  Puzzle,
  Rocket,
  Server,
  Smartphone,
  Sparkles,
  Terminal,
  Workflow,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type Project = {
  name: string;
  number: string;
  status: string;
  description: string;
  technologies: string[];
  role: string;
  accent: string;
  className: string;
};

type SkillCluster = {
  name: string;
  blurb: string;
  color: string;
  items: string[];
};

const routes = [
  { path: "/", label: "Home", short: "01" },
  { path: "/about", label: "About", short: "02" },
  { path: "/skills", label: "Skills", short: "03" },
  { path: "/projects", label: "Projects", short: "04" },
  { path: "/experience", label: "Experience", short: "05" },
  { path: "/missions", label: "Missions", short: "06" },
  { path: "/contact", label: "Contact", short: "07" },
];

const projects: Project[] = [
  { name: "EDITH", number: "01", status: "In Development", description: "An Android personal assistant project focused on useful device-level tools, automation, and a clean conversational interface.", technologies: ["Java", "Android", "APIs", "API Integration"], role: "Concept · Product Design · Development · Integration", accent: "LIME / COBALT", className: "edith" },
  { name: "FITFORGE", number: "02", status: "In Development", description: "A fitness platform concept combining workout tracking, exercise guidance, progress tracking, and community features.", technologies: ["Product Concept", "Feature Design", "UI", "Development"], role: "Product Concept · Feature Design · UI · Development", accent: "AMBER / SIGNAL", className: "fitforge" },
];

const capabilities = [
  { icon: Globe2, name: "WEB", copy: "Websites and interactive surfaces from first sketch to live interface.", tags: ["Frontend", "React", "UI / UX", "APIs"] },
  { icon: Smartphone, name: "ANDROID", copy: "Useful mobile experiences with room for intelligence and device context.", tags: ["Java", "Android", "Automation Apps", "Integration"] },
  { icon: Gamepad2, name: "MINECRAFT", copy: "Servers, plugins, configuration, management, texture, optimization.", tags: ["Servers", "Plugins", "Paper", "Optimization"] },
  { icon: MessageSquare, name: "DISCORD", copy: "The system behind the conversation: bots, roles, channels, automation.", tags: ["Bots", "Setup", "Roles", "Workflows"] },
  { icon: Bot, name: "SYSTEMS + AUTO", copy: "APIs and automation workflows that turn repetitive work into flow.", tags: ["APIs", "Prompting", "Automation", "Tools"] },
  { icon: Sparkles, name: "DIGITAL CREATION", copy: "Courses, digital products, prototypes, and educational content.", tags: ["Courses", "Products", "Content", "Prototypes"] },
];

const clusters: SkillCluster[] = [
  { name: "WEB", blurb: "Interactive web experiences with clear systems underneath.", color: "lime", items: ["Website Developer", "Website Builder", "Frontend", "Interactive Web Experiences"] },
  { name: "ANDROID", blurb: "Mobile product thinking with APIs and automation in the loop.", color: "blue", items: ["Android Developer", "App Builder", "API Integration", "Automation Applications"] },
  { name: "SYSTEMS", blurb: "Connecting tools and automation into useful workflows.", color: "violet", items: ["API Integration", "Application Development", "Workflow Design", "Automation Tools"] },
  { name: "MINECRAFT", blurb: "Premium infrastructure for persistent digital worlds.", color: "amber", items: ["Server Developer", "Server Manager", "Plugin Creator", "Configuration", "Optimization", "Texture Packs"] },
  { name: "DISCORD", blurb: "Community systems that make the invisible layer legible.", color: "blue", items: ["Bot Maker", "Bot Developer", "Server Setup", "Server Manager", "Automation", "Integrations"] },
  { name: "AUTOMATION", blurb: "Less repetition. More room to build.", color: "lime", items: ["Workflow Systems", "API Connections", "Triggers", "Prompt Chains"] },
  { name: "DIGITAL CREATION", blurb: "Make the learning and the artifact share a surface.", color: "amber", items: ["Online Courses", "Digital Products", "Educational Content", "Project Prototyping"] },
];

const missions = [
  ["01", "Launch major projects", "Move ideas from notes to usable releases.", "Building"],
  ["02", "Build advanced software systems", "Keep learning how intelligence becomes utility.", "Exploring"],
  ["03", "Create useful web platforms", "Make interfaces that help someone do a thing.", "Planning"],
  ["04", "Build advanced Minecraft systems", "Treat game infrastructure like real engineering.", "Building"],
  ["05", "Build Discord automation", "Reduce repetitive work for online communities.", "Exploring"],
  ["06", "Participate in hackathons", "Put unfinished ideas in rooms with other builders.", "Planning"],
  ["07", "Create useful online courses", "Turn experiments into useful learning paths.", "Planning"],
];

function RouteLink({ href, children, className = "" }: { href: string; children: ReactNode; className?: string }) {
  return <Link href={href} className={className} onClick={() => window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior })}>{children}</Link>;
}

function AmbientCanvas({ mode = "home" }: { mode?: string }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointer = useRef({ x: 0.5, y: 0.5, active: false });
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const count = window.innerWidth < 720 ? 32 : 68;
    const points = Array.from({ length: count }, (_, index) => ({ x: Math.random(), y: Math.random(), z: Math.random(), drift: (Math.random() - .5) * .00022, phase: index * .7 }));
    let raf = 0;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const draw = (time: number) => {
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      ctx.clearRect(0, 0, width, height);
      const hue = mode === "minecraft" ? "241,180,91" : mode === "contact" ? "126,165,255" : "200,255,61";
      const mapped = points.map((point) => {
        point.x += reduced ? 0 : point.drift;
        if (point.x > 1.08) point.x = -.08;
        if (point.x < -.08) point.x = 1.08;
        const driftY = reduced ? 0 : Math.sin(time * .00035 + point.phase) * .006;
        const px = (point.x + (pointer.current.x - .5) * point.z * (pointer.current.active ? .065 : .018)) * width;
        const py = (point.y + driftY + (pointer.current.y - .5) * point.z * (pointer.current.active ? .05 : .014)) * height;
        return { px, py, z: point.z, r: .6 + point.z * 2.1 };
      });
      mapped.forEach((point, index) => mapped.slice(index + 1).forEach((other) => {
        const distance = Math.hypot(point.px - other.px, point.py - other.py);
        if (distance < 128 && point.z > .18 && other.z > .18) {
          ctx.strokeStyle = `rgba(${hue},${(1 - distance / 128) * .17 * Math.min(point.z + other.z, 1)})`;
          ctx.lineWidth = .55;
          ctx.beginPath(); ctx.moveTo(point.px, point.py); ctx.lineTo(other.px, other.py); ctx.stroke();
        }
      }));
      mapped.forEach((point) => { ctx.fillStyle = `rgba(${hue},${.12 + point.z * .5})`; ctx.beginPath(); ctx.arc(point.px, point.py, point.r, 0, Math.PI * 2); ctx.fill(); });
      raf = requestAnimationFrame(draw);
    };
    resize();
    window.addEventListener("resize", resize);
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [mode]);
  const onMove = (event: PointerEvent<HTMLCanvasElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    pointer.current = { x: (event.clientX - bounds.left) / bounds.width, y: (event.clientY - bounds.top) / bounds.height, active: true };
  };
  return <canvas ref={canvasRef} className="ambient-canvas" aria-hidden="true" onPointerMove={onMove} onPointerLeave={() => { pointer.current.active = false; }} />;
}

function InterfaceFX() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? window.scrollY / max : 0);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);

  useEffect(() => {
    const move = (event: MouseEvent) => {
      document.documentElement.style.setProperty("--cursor-x", `${event.clientX}px`);
      document.documentElement.style.setProperty("--cursor-y", `${event.clientY}px`);
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => window.removeEventListener("pointermove", move);
  }, []);

  return <><div className="scroll-progress" style={{ transform: `scaleX(${progress})` }} /><div className="cursor-glow" aria-hidden="true" /></>;
}

function TopBar() {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  return <>
    <header className="top-bar">
      <RouteLink href="/" className="brand-lockup"><span className="brand-mark"><img src="/zenmogs-mark.svg" alt="" /></span><span>ZENMOGS</span><b>_</b></RouteLink>
      <span className="top-status"><i /> system online · {location === "/" ? "home" : location.slice(1)}</span>
      <button type="button" className="menu-toggle" aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? "CLOSE" : "MENU"}</button>
      <nav className={`top-links ${menuOpen ? "open" : ""}`} aria-label="Primary navigation">
        {routes.slice(1, 5).map((route) => <RouteLink key={route.path} href={route.path} className={location === route.path ? "active" : ""}>{route.label}</RouteLink>)}
        <RouteLink href="/contact" className="top-contact">Open channel <ArrowUpRight size={13} /></RouteLink>
      </nav>
    </header>
  </>;
}

function DotRail() {
  const [location] = useLocation();
  return <aside className="dot-rail" aria-label="Section navigation">{routes.map((route) => <RouteLink key={route.path} href={route.path} className={`dot-link ${location === route.path ? "active" : ""}`} aria-label={route.label}><span className="dot-label"><b>{route.short}</b>{route.label}</span><i /></RouteLink>)}</aside>;
}

function Footer() {
  return <footer className="site-footer"><div className="footer-brand"><span className="brand-mark"><img src="/zenmogs-mark.svg" alt="" /></span><span>ZENMOGS<span className="signal">_</span></span></div><p>Student developer. Builder. Creator.</p><div className="footer-social"><a href="https://github.com/ZenMogs" target="_blank" rel="noreferrer">GitHub</a><a href="https://instagram.com/whatd.ya.say" target="_blank" rel="noreferrer">Instagram</a><a href="mailto:snkslow@gmail.com">Email</a></div><span className="footer-copy">© 2026 / build --everything</span></footer>;
}

export function SiteLayout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const mode = location === "/projects" ? "projects" : location === "/contact" ? "contact" : location === "/about" ? "about" : location === "/skills" ? "skills" : location === "/missions" ? "minecraft" : "home";
  return <div className={`cosmos-shell mode-${mode}`}><InterfaceFX /><AmbientCanvas mode={mode} /><TopBar /><DotRail /><div className="route-content">{children}</div><Footer /></div>;
}

function PageIntro({ number, eyebrow, title, accent, copy, signal }: { number: string; eyebrow: string; title: string; accent?: string; copy: string; signal: string }) {
  return <section className={`page-intro page-section intro-${eyebrow.toLowerCase()}`}><div className="container page-intro-grid"><div><span className="page-number">{number}</span><div className="eyebrow"><i /> {eyebrow}</div><h1 className="page-title">{title} {accent && <em>{accent}</em>}</h1><p className="page-copy">{copy}</p></div><div className="signal-console"><span className="console-top"><span>ZENMOGS / {eyebrow.toUpperCase()}</span><b>LIVE</b></span><span className="console-line" /><strong>{signal}</strong><span className="console-prompt">scroll / inspect / interact<span className="cursor" /></span></div></div></section>;
}

function SectionKicker({ children }: { children: ReactNode }) {
  return <span className="section-kicker"><i /> {children}</span>;
}

export function HomePage() {
  const heroRef = useRef<HTMLElement | null>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, -150]);
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, .92]);
  const terminalY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  return <main>
    <section ref={heroRef} className="hero-stage page-section">
      <div className="hero-portal" />
      <div className="container hero-layout">
        <motion.div className="hero-copy-block" style={{ y: heroY, scale: heroScale }}>
          <div className="hero-signature"><img src="/zenmogs-mark.svg" alt="" /><span>ZENMOGS / WORKBENCH ONLINE</span></div>
          <div className="eyebrow"><i /> currently building</div>
          <h1 className="hero-title">ZENMOGS<span className="signal">.</span><br /><span className="outline">BUILDING</span><br />DIGITAL THINGS<span className="signal">.</span></h1>
          <p className="hero-kicker">Student developer <b>·</b> Builder <b>·</b> Creator</p>
          <p className="hero-description">I build ideas into digital experiences. Websites. Apps. Software systems. Minecraft servers. Plugins. Discord systems. Digital products. Online courses.</p>
          <div className="hero-actions"><RouteLink href="/projects" className="button button-primary">Explore my work <ArrowUpRight size={15} /></RouteLink><RouteLink href="/skills" className="button button-ghost">What I build <ArrowDown size={15} /></RouteLink></div>
          <div className="hero-stats"><span><b>06</b> build domains</span><span><b>02</b> active concepts</span><span><b className="signal">∞</b> ideas in queue</span></div>
        </motion.div>
        <motion.div className="hero-terminal" style={{ y: terminalY }}><div className="terminal-head"><span><Terminal size={12} /> zenmogs@dev:~</span><span className="terminal-dots"><i /><i /><i /></span></div><div className="terminal-body"><div><span className="prompt">$</span> build --everything</div>{["WEB", "ANDROID", "SYSTEMS", "MINECRAFT", "DISCORD", "AUTOMATION"].map((line, index) => <div key={line} className="terminal-row" style={{ animationDelay: `${index * 180}ms` }}><span className="prompt">&gt;</span><span>{line}</span><Check size={12} /></div>)}<div className="terminal-status">STATUS: <span>BUILDING...</span><i className="cursor" /></div></div></motion.div>
      </div>
      <div className="hero-footerline"><span>01 / 07</span><span>scroll to enter the world <ArrowDown size={13} /></span></div>
    </section>
    <section className="home-intro page-section"><div className="container split-intro"><div><SectionKicker>the short version</SectionKicker><h2 className="display-title">Wide curiosity.<br /><span className="signal">Real builds.</span></h2></div><p className="body-large">Instead of staying inside one category, I like learning how different technologies connect — then pushing them together until a useful experience shows up.</p></div></section>
    <section className="capability-preview page-section"><div className="container"><div className="section-heading-row"><div><SectionKicker>capability map</SectionKicker><h2 className="display-title">What I build <span className="outline-text">next</span></h2></div><RouteLink href="/skills" className="text-link">Open the constellation <ArrowRight size={14} /></RouteLink></div><div className="capability-grid">{capabilities.map(({ icon: Icon, name, copy, tags }, index) => <motion.article key={name} className="capability-tile" initial={{ opacity: 0, y: 30, rotateX: 8 }} whileInView={{ opacity: 1, y: 0, rotateX: 0 }} viewport={{ once: true, amount: .22 }} transition={{ delay: index * .06, duration: .55 }} whileHover={{ y: -10, rotateX: -3, rotateY: index % 2 ? 2 : -2 }}><span className="tile-index">0{index + 1}</span><span className="tile-icon"><Icon size={20} strokeWidth={1.5} /></span><h3>{name}</h3><p>{copy}</p><div className="tile-tags">{tags.map((tag) => <span key={tag}>{tag}</span>)}</div></motion.article>)}</div></div></section>
  </main>;
}

export function AboutPage() {
  return <main><PageIntro number="02" eyebrow="About" title="WHO IS" accent="ZENMOGS?" copy="A student developer and builder who likes finding the edge between ‘what if?’ and ‘it works.’" signal="curiosity → system → experience" /><section className="page-section about-world"><div className="container about-layout"><div className="about-manifesto"><SectionKicker>identity / working philosophy</SectionKicker><p>I'm ZenMogs, a student developer and builder who enjoys experimenting with technology and turning random ideas into real projects.</p><p className="muted">I work across software, web development, Android apps, Minecraft infrastructure, Discord systems, automation, and digital creation. I like learning how different technologies connect — then pushing them together until a useful experience shows up.</p><RouteLink href="/projects" className="button button-ghost">Inspect the builds <ArrowUpRight size={14} /></RouteLink></div><div className="about-bento">{[["BUILD", "Turn concepts into working projects."], ["LEARN", "Learn by experimenting and building."], ["EXPLORE", "Try new technologies and ideas."], ["CREATE", "Make useful digital experiences."]].map(([title, copy], index) => <motion.article key={title} className={`about-card about-card-${index + 1}`} initial={{ opacity: 0, y: 80, rotate: index % 2 ? 4 : -4 }} whileInView={{ opacity: 1, y: 0, rotate: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .7, delay: index * .1 }} whileHover={{ y: -14, rotate: index % 2 ? -2 : 2 }}><span>0{index + 1}</span><h3>{title}</h3><p>{copy}</p><div className="card-orbit" /></motion.article>)}</div></div></section></main>;
}

export function SkillsPage() {
  const [selected, setSelected] = useState(clusters[3]);
  return <main><PageIntro number="03" eyebrow="Skills" title="THE SKILL" accent="CONSTELLATION" copy="No percentage bars. Just the systems, tools, and patterns I keep pulling into the workbench." signal="select a node / expand the system" /><section className="page-section skill-world"><div className="container skill-layout"><div className="constellation-stage"><div className="constellation-ring ring-one" /><div className="constellation-ring ring-two" /><div className="constellation-lines" />{clusters.map((cluster, index) => <button type="button" key={cluster.name} className={`skill-node node-${index + 1} ${selected.name === cluster.name ? "selected" : ""} node-${cluster.color}`} onClick={() => setSelected(cluster)}><span>{cluster.name}</span><i /></button>)}<div className="constellation-core"><img src="/zenmogs-mark.svg" alt="" /><strong>ZENMOGS</strong><span>signal core</span></div></div><AnimatePresence mode="wait"><motion.div key={selected.name} className="skill-detail" initial={{ opacity: 0, x: 28, filter: "blur(8px)" }} animate={{ opacity: 1, x: 0, filter: "blur(0px)" }} exit={{ opacity: 0, x: -20, filter: "blur(8px)" }} transition={{ duration: .3 }}><SectionKicker>selected node</SectionKicker><h2>{selected.name}</h2><p>{selected.blurb}</p><div className="skill-detail-list">{selected.items.map((item, index) => <span key={item}><b>0{index + 1}</b>{item}</span>)}</div><div className="skill-hint"><CircleDot size={13} /> click another node to move the camera</div></motion.div></AnimatePresence></div></section></main>;
}

function FlyingPhone() {
  return <div className="phone-wrap"><div className="phone-device"><div className="phone-side" /><div className="phone-screen"><div className="phone-notch" /><span className="phone-time">09:41</span><div className="phone-orb"><Sparkles size={24} /></div><strong>EDITH</strong><small>assistant core / online</small><div className="phone-input">Ask EDITH anything <ArrowUpRight size={12} /></div><div className="phone-pills"><i /><i /><i /></div></div></div></div>;
}

function ProjectVisual({ project, index }: { project: Project; index: number }) {
  return <div className={`project-visual project-visual-${project.className}`}><div className="project-grid" /><div className="project-orbit orbit-a" /><div className="project-orbit orbit-b" /><span className="project-label">{project.number} / {project.accent}</span><span className="project-visual-name">{project.name}</span>{index === 0 && <div className="mini-chip">ANDROID / SYSTEMS</div>}{index === 1 && <div className="fitforge-dashboard"><span>FITFORGE / TRAINING LOOP</span><strong>WEEK 04</strong><div className="fitforge-bars"><i /><i /><i /><i /><i /><i /><i /></div><small>workout tracking · progress · community</small></div>}</div>;
}

export function ProjectsPage() {
  const phoneStage = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({ target: phoneStage, offset: ["start end", "end start"] });
  const phoneY = useTransform(scrollYProgress, [0, .35, .72, 1], [180, 10, -20, -220]);
  const phoneX = useTransform(scrollYProgress, [0, .35, .72, 1], [-140, 20, 80, 210]);
  const phoneRotate = useTransform(scrollYProgress, [0, .35, .72, 1], [-24, 4, 10, 30]);
  const phoneScale = useTransform(scrollYProgress, [0, .35, .72, 1], [.58, 1, 1.05, .7]);
  return <main><PageIntro number="04" eyebrow="Projects" title="THE" accent="WORKBENCH" copy="Two active concepts. Presented honestly. Designed like things worth opening, not résumé entries." signal="scroll / deploy / inspect" /><section ref={phoneStage} className="phone-sequence page-section"><div className="container phone-sequence-grid"><div className="sequence-copy"><SectionKicker>project 01 / edith</SectionKicker><h2 className="display-title">A personal assistant,<br /><span className="signal">in orbit.</span></h2><p className="body-copy">An Android personal assistant project focused on useful device-level tools, automation, and a clean conversational interface.</p><div className="stack-row">{projects[0].technologies.map((tech) => <span key={tech}>{tech}</span>)}</div><div className="sequence-note"><span className="signal">01</span><span>phone enters the scene</span><span className="sequence-line" /></div></div><div className="phone-stage"><div className="phone-stage-grid" /><motion.div className="flying-phone" style={{ y: phoneY, x: phoneX, rotate: phoneRotate, scale: phoneScale }}><FlyingPhone /></motion.div><span className="stage-caption">scroll controlled object / EDITH</span></div></div></section><section className="project-list page-section"><div className="container"><div className="section-heading-row"><div><SectionKicker>project archive</SectionKicker><h2 className="display-title">Built in public<span className="signal">.</span></h2></div><span className="archive-count">02 ACTIVE CONCEPTS</span></div><div className="project-stack">{projects.map((project, index) => <motion.article key={project.name} className="project-row" initial={{ opacity: 0, y: 80, rotateX: 12 }} whileInView={{ opacity: 1, y: 0, rotateX: 0 }} viewport={{ once: true, amount: .2 }} transition={{ duration: .7 }}><ProjectVisual project={project} index={index} /><div className="project-details"><div className="project-meta"><span className="status"><i /> {project.status}</span><span className="project-number">{project.number}</span></div><h3>{project.name}</h3><p>{project.description}</p><div className="stack-row">{project.technologies.map((tech) => <span key={tech}>{tech}</span>)}</div><div className="project-bottom"><span>{project.role}</span><button type="button" onClick={() => toast.info(`${project.name} build notes`, { description: "Detailed public links and screenshots will appear here when available." })}>Open build notes <MoveUpRight size={14} /></button></div></div></motion.article>)}<div className="future-build"><span className="future-orbit" /><div><strong>More builds incoming...</strong><small>next signal / loading</small></div></div></div></div></section></main>;
}

export function ExperiencePage() {
  const timelineRef = useRef<HTMLDivElement | null>(null);
  const { scrollYProgress } = useScroll({ target: timelineRef, offset: ["start .7", "end .7"] });
  const lineScale = useTransform(scrollYProgress, [0, 1], [0, 1]);
  const phases = [["IDEA", "Spot the spark."], ["RESEARCH", "Find the shape."], ["DESIGN", "Make it legible."], ["BUILD", "Turn it on."], ["TEST", "Break it safely."], ["LAUNCH", "Share the result."], ["IMPROVE", "Keep the loop alive."]];
  return <main><PageIntro number="05" eyebrow="Experience" title="FROM IDEA" accent="TO ITERATION" copy="A simple loop I trust: make the unknown smaller, then make the thing real." signal="independent student developer / 2025 → present" /><section className="page-section timeline-world"><div className="container"><div className="timeline-header"><SectionKicker>build sequence</SectionKicker><p>Scroll to move the signal through the phases.</p></div><div ref={timelineRef} className="cinematic-timeline"><div className="timeline-track"><motion.span style={{ scaleY: lineScale }} /></div>{phases.map(([title, copy], index) => <motion.div key={title} className={`timeline-node ${index < 4 ? "seeded" : ""}`} initial={{ opacity: 0, x: index % 2 ? 24 : -24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .65 }} transition={{ duration: .45, delay: index * .035 }}><span className="timeline-marker">0{index + 1}</span><div><h3>{title}</h3><p>{copy}</p></div></motion.div>)}</div><div className="experience-console"><div><SectionKicker>current role</SectionKicker><h2>Independent Student Developer</h2><span>2025 — PRESENT</span></div><p>Building websites, Android applications, connected software projects, Minecraft systems, Discord systems, plugins, automation workflows, and digital products independently.</p></div></div></section></main>;
}

export function MissionsPage() {
  return <main><PageIntro number="06" eyebrow="Missions" title="CURRENT" accent="MISSIONS" copy="The active queue is intentionally honest. No fake percentages — just the next systems worth exploring." signal="queue / seven open loops" /><section className="page-section mission-world"><div className="container"><div className="mission-console-head"><SectionKicker>mission control</SectionKicker><span><i /> live queue</span></div><div className="mission-queue">{missions.map(([number, title, copy, state], index) => <motion.article key={title} className="mission-row" initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .25 }} transition={{ delay: index * .065, duration: .5 }}><span className="mission-number">{number}</span><div className="mission-copy"><h2>{title}</h2><p>{copy}</p></div><span className={`mission-state state-${state.toLowerCase()}`}>{state}</span><ChevronRight size={16} /></motion.article>)}</div></div></section></main>;
}

function DiscordContactCard() {
  const copyHandle = () => {
    if (navigator.clipboard) void navigator.clipboard.writeText("z4nmogs");
    toast.success("Discord username copied", { description: "Search for z4nmogs in Discord." });
  };
  return <a className="contact-card discord-card" href="https://discord.com/app" target="_blank" rel="noreferrer" onClick={copyHandle}><span className="contact-card-icon"><MessageSquare size={22} /></span><span className="contact-card-label">DISCORD</span><strong>@z4nmogs</strong><small>open Discord / copy username</small><ArrowUpRight className="contact-arrow" size={17} /></a>;
}

export function ContactPage() {
  return <main><PageIntro number="07" eyebrow="Contact" title="LET'S BUILD" accent="SOMETHING." copy="Got an idea worth building? Open a channel and send it through." signal="open channel / awaiting signal" /><section className="page-section contact-world"><div className="contact-portal"><div className="portal-ring portal-ring-a" /><div className="portal-ring portal-ring-b" /><div className="portal-core"><img src="/zenmogs-mark.svg" alt="" /></div></div><div className="container contact-layout"><div className="contact-invite"><SectionKicker>direct connections</SectionKicker><h2 className="display-title">Bring the spark.<br /><span className="signal">I’ll build the system.</span></h2><p className="body-copy">Each contact method is a real path — not a placeholder.</p></div><div className="contact-grid"><a className="contact-card github-card" href="https://github.com/ZenMogs" target="_blank" rel="noreferrer"><span className="contact-card-icon"><Github size={22} /></span><span className="contact-card-label">GITHUB</span><strong>ZenMogs</strong><small>inspect the public workbench</small><ArrowUpRight className="contact-arrow" size={17} /></a><DiscordContactCard /><a className="contact-card instagram-card" href="https://instagram.com/whatd.ya.say" target="_blank" rel="noreferrer"><span className="contact-card-icon"><Instagram size={22} /></span><span className="contact-card-label">INSTAGRAM</span><strong>@whatd.ya.say</strong><small>follow the maker outside the code</small><ArrowUpRight className="contact-arrow" size={17} /></a><a className="contact-card email-card" href="mailto:snkslow@gmail.com"><span className="contact-card-icon"><Mail size={22} /></span><span className="contact-card-label">EMAIL</span><strong>snkslow@gmail.com</strong><small>send the brief / start a conversation</small><ArrowUpRight className="contact-arrow" size={17} /></a></div></div></section></main>;
}

export default HomePage;
