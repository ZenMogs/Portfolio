# ZenMogs Cinematic UI Upgrade

- [x] Keep the existing ZenMogs content, assets, and project concept while moving from one long page to route-based views.
- [x] Add a premium 3-dot section rail with labels, active glow, connecting line, hover tooltips, and smooth route transitions.
- [x] Build separate Home, About, Skills, Projects, Experience, Missions, and Contact routes.
- [x] Add stronger scroll-driven motion: perspective panels, floating elements, route curtains, and section-specific motion systems.
- [x] Add the EDITH flying-phone sequence as a CSS 3D device with scroll-controlled transforms.
- [x] Add interactive skill constellation node selection and related-skill expansion.
- [x] Add real contact destinations from the brief, including GitHub, Discord, Instagram, and email.
- [x] Preserve honest placeholders for unknown project demo URLs and unavailable screenshots/metrics.
- [x] Verify desktop/mobile behavior, reduced motion, runtime logs, TypeScript, and production build output.
- [x] Save a fresh checkpoint and report the substantial UI changes.
